package com.cts.smart.ivr.controller;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.cts.ivr.bean.EmployeeClass;
import com.cts.ivr.daoImpl.ActivityMethodImpl;

@WebServlet("/SignUpcontroller")
public class SignUpcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ActivityMethodImpl methodObject;

	ActivityMethodImpl method = new ActivityMethodImpl();

	boolean status = false;

	RequestDispatcher dispatcher;

	@Resource(name = "jdbc/smart_ivr")
	private DataSource dataSource;

	@Override
	public void init() throws ServletException {
		super.init();
		try {
			methodObject = new ActivityMethodImpl(dataSource);
		} catch (Exception exc) {
			throw new ServletException(exc);
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			System.out.println("doGet method of SignUpcontroller");
			request.getRequestDispatcher("/StartUp.jsp").forward(request, response);
		} catch (Exception exc) {
			throw new ServletException(exc);
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			System.out.println("doPost method of Studentcontroller");

			// read student id from data String email
			String fName = request.getParameter("fName");
			String lName = request.getParameter("lName");
			String employeeId = request.getParameter("EmployeeId");
			String email = request.getParameter("email");
			String mobNumber = request.getParameter("mobNumber");
			String pwd = request.getParameter("password1");
			// delete student from database
			EmployeeClass emp = new EmployeeClass(employeeId, fName, lName, email, mobNumber, pwd);
			boolean emailStatus = methodObject.emailValidation(email);
			boolean empIdStatus = methodObject.empIdValidation(employeeId);
			if (emailStatus || empIdStatus) {
				System.out.println("Email id or Employee id is already existed,Please add valid details...");
				dispatcher = request.getRequestDispatcher("/Signup.jsp");
				dispatcher.forward(request, response);
			} else {
				methodObject.addEmployee(emp);
				request.setAttribute("success", "User got registered");
				dispatcher = request.getRequestDispatcher("/Login.jsp");
				dispatcher.forward(request, response);
			}
			
			
		} catch (Exception exc) {
			throw new ServletException(exc);
		}
	}

	
	private void Login(HttpServletRequest request, HttpServletResponse response) throws Exception {

		// read student id from data String email
		String email = request.getParameter("email");
		String pwd = request.getParameter("password");
		// delete student from database
		boolean status = methodObject.loginValidation(email, pwd);

		if (status) {
			System.out.println("Login successful");
			request.setAttribute("success", "Login successful");
			dispatcher = request.getRequestDispatcher("/Linkpage.jsp");
			dispatcher.forward(request, response);
		} else {
			System.out.println("Login Error");
			request.setAttribute("<h1> style='red' errorMessage", "Invalid user or password </h1>");
			// out.print(<html><h1> "Sorry, email or password is wrong" </h1></html>);
			request.setAttribute("errorMessage", "Invalid user or password");
			dispatcher = request.getRequestDispatcher("/Login.jsp");
			dispatcher.forward(request, response);
		}
	}

	private void CheckLoginStatus(HttpServletRequest request, HttpServletResponse response) throws Exception {
		boolean status = false;
		RequestDispatcher dispatcher;
		if (status) {
			System.out.println("Login successful");
			request.setAttribute("success", "Login successful");
			dispatcher = request.getRequestDispatcher("/Linkpage.jsp");
			dispatcher.forward(request, response);
		} else {
			request.setAttribute("errorMessage", "Invalid user or password");
			System.out.println("Invalid user or password");
			dispatcher = request.getRequestDispatcher("/Linkpage.jsp");
			dispatcher.forward(request, response);
		}
	}
}
