package com.cts.smart.ivr.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.cts.ivr.bean.EmployeeClass;
import com.cts.ivr.daoImpl.ActivityMethodImpl;

@WebServlet("/AddactivityServlet")
public class AddactivityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ActivityMethodImpl methodObject;

	ActivityMethodImpl method = new ActivityMethodImpl();

	boolean status = false;

	RequestDispatcher dispatcher;

	@Resource(name = "jdbc/smart_ivr")
	private DataSource dataSource;

	@Override
	public void init() throws ServletException {
		super.init();
		try {
			methodObject = new ActivityMethodImpl(dataSource);
		} catch (Exception exc) {
			throw new ServletException(exc);
		}
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			System.out.println("doGet method of AddactivityServlet");
			request.getRequestDispatcher("/StartUp.jsp").forward(request, response);
					} 
		catch (Exception exc) {
			throw new ServletException(exc);
		}
	}

	private void checkAccess(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		String empemailid= request.getParameter("email");
		
		System.out.println("email is "+empemailid);
		
		String role=methodObject.checkAccess(empemailid);
		
		if (role.equalsIgnoreCase("Manager") ){
			
			dispatcher = request.getRequestDispatcher("/Managerview.jsp");
			dispatcher.forward(request,response);
		} else {
			addActivity(request, response);
			
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			System.out.println("doPost method of AddactivityServlet");
			checkAccess(request, response);
			
			
		} catch (Exception exc) {
			throw new ServletException(exc);
		}
	}

	private void addActivity(HttpServletRequest request, HttpServletResponse response) throws Exception {

		String date = request.getParameter("selDate");
		System.out.println("Date is " + date);

		String time = request.getParameter("time");
		String customer = request.getParameter("customer");
		String categorization = request.getParameter("categorization");
		String description = request.getParameter("description");
		String email=request.getParameter("email");
		System.out.println("Inside AddActivity method");
		// System.out.println("Date after change pattern " +
		// ActivityMethodImpl.getSQLDate(date));
		System.out.println("Inside AddActivity method & date is " + date);
		// Add activity to database
		methodObject.addActivity(date, time, customer, categorization, description,email);
		request.setAttribute("errorMessage", "Invalid user or password");
		dispatcher = request.getRequestDispatcher("/Activity.jsp");
		dispatcher.forward(request, response);
	}
	
	
}
