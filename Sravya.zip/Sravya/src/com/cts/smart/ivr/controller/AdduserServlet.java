package com.cts.smart.ivr.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.cts.ivr.bean.ActivityBean;
import com.cts.ivr.daoImpl.ActivityMethodImpl;

@WebServlet("/AdduserController")
public class AdduserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ActivityMethodImpl methodObject;

	ActivityMethodImpl method = new ActivityMethodImpl();

	boolean status = false;

	RequestDispatcher dispatcher;

	@Resource(name = "jdbc/smart_ivr")
	private DataSource dataSource;

	@Override
	public void init() throws ServletException {
		super.init();
		try {
			methodObject = new ActivityMethodImpl(dataSource);
		} catch (Exception exc) {
			throw new ServletException(exc);
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			System.out.println("doGet method of AdduserServlet");
			request.getRequestDispatcher("/StartUp.jsp").forward(request, response);
		} catch (Exception exc) {
			throw new ServletException(exc);
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			System.out.println("doPost method of ViewActivityController");
			// listEmpActivity(request, response);
			
			Adduser(request, response);
		} catch (Exception exc) {
			throw new ServletException(exc);
		}
	}

	private void Adduser(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
		// TODO Auto-generated method stub
		String empemailid = request.getParameter("email");
		System.out.println("email is " + empemailid);

		String role = request.getParameter("role");
		 
		
		System.out.println("Inside Adduser method " + empemailid);
		// Add activity to database
		methodObject.addUser(empemailid,role);
		dispatcher = request.getRequestDispatcher("/Managerlink.jsp");
		dispatcher.forward(request, response);
		
	}
}