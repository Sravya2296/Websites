package com.cts.ivr.daoImpl;

public class DownloadActivityList {

}
