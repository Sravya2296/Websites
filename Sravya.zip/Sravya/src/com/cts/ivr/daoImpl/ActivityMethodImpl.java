package com.cts.ivr.daoImpl;

import java.io.Writer;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import java.util.List;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.sql.DataSource;
import org.postgresql.copy.CopyManager;
import org.postgresql.core.BaseConnection;
import com.cts.ivr.bean.ActivityBean;
import com.cts.ivr.bean.EmployeeClass;
import com.cts.ivr.dao.ActivityMethods;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.JOptionPane;
import org.postgresql.copy.CopyManager;
import org.postgresql.core.BaseConnection;

public class ActivityMethodImpl implements ActivityMethods {
	Properties p = new Properties();

	public ActivityMethodImpl() {
		super();
	}

	private DataSource dataSource;

	public ActivityMethodImpl(DataSource theDataSource) {
		dataSource = theDataSource;
	}

	public List<ActivityBean> getActivityDetails(String fromDate, String toDate, String customer) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		String activitydate, activitytime, customerName, description,emailid = null;
		ActivityBean activityObject = null;
		List<ActivityBean> studentBean = new ArrayList<ActivityBean>();

		try {
			myConn = dataSource.getConnection();

			String sql = "SELECT * FROM activity_detail WHERE activitydate BETWEEN TO_DATE(?,'mm/dd/yyyy') AND TO_DATE(?,'mm/dd/yyyy')AND customer=?";

			// create prepared statement
			myStmt = myConn.prepareStatement(sql);

			// set params
			myStmt.setString(1, fromDate);
			myStmt.setString(2, toDate);
			myStmt.setString(3, customer);
			// execute statement
			myRs = myStmt.executeQuery();

			while (myRs.next()) {
				activitydate = myRs.getString("activitydate");
				activitytime = myRs.getString("activitytime");
				customerName = myRs.getString("customer");
				description = myRs.getString("description");
                emailid=myRs.getString("empemailid");
				System.out.println(
						"View activity: " + activitydate + " " + activitytime + " " + customerName + " " + description  );
				// use the studentId during construction
				activityObject = new ActivityBean(activitydate, activitytime, customerName, description,emailid);
				studentBean.add(activityObject);
			}
		} catch (Exception e) {
			System.out.println("Exception in getActivityDetails method- " + e);
		} finally {
			// close JDBC objects
			close(myConn, myStmt, myRs);
		}
		return studentBean;
	}

	/*
	 * public static Date getSQLDate(LocalDate date) { return
	 * java.sql.Date.valueOf(date); }
	 * 
	 * public static LocalDate getUtilDate(Date sqlDate) { return
	 * sqlDate.toLocalDate(); }
	 */

	private void close(Connection myConn, Statement myStmt, ResultSet myRs) {

		try {
			if (myRs != null) {
				myRs.close();
			}

			if (myStmt != null) {
				myStmt.close();
			}

			if (myConn != null) {
				myConn.close(); // doesn't really close it ... just puts back in connection pool
			}
		} catch (Exception exc) {
			exc.printStackTrace();
		}
	}

	public boolean loginValidation(String email, String pwd) {
		boolean status = false;
		Connection myConn = null;
		PreparedStatement myStmt = null;
		try {

			System.out.println("Inside Login validation method");
			myConn = dataSource.getConnection();
			String sql = "select * from register_user where emailid=? and password=?";

			myStmt = myConn.prepareStatement(sql);

			myStmt.setString(1, email);
			myStmt.setString(2, pwd);

			System.out.println("Value of email :" + email);

			System.out.println("Value of pwd :" + pwd);

			ResultSet rs = myStmt.executeQuery();
			status = rs.next();

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
		System.out.println("Status is: " + status);
		return status;
	}

	public void addEmployee(EmployeeClass theStudent) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;

		try {
			// get db connection
			myConn = dataSource.getConnection();

			/*
			 * insert into
			 * register_user(empfirstname,emplastname,emailid,mobilenumber,password,
			 * employeeid) values
			 * ('Shradha','Rathore','shradha.rathore@cognizant.com','9989898989','Shradha@
			 * 123','780382')
			 */

			String sql = "insert into register_user "
					+ "(empfirstname,emplastname,emailid,mobilenumber,password,employeeid) " + "values (?, ?, ?,?,?,?)";

			myStmt = myConn.prepareStatement(sql);

			// set the param values for the student
			myStmt.setString(1, theStudent.getFirstName());
			myStmt.setString(2, theStudent.getLastName());
			myStmt.setString(3, theStudent.getEmail());
			myStmt.setString(4, theStudent.getMobNumber());
			myStmt.setString(5, theStudent.getPassword());
			myStmt.setString(6, theStudent.getEmpId());

			// execute sql insert
			myStmt.execute();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
	}

	public EmployeeClass getStudent() throws Exception {
		String theStudentId = "Shradha";
		EmployeeClass theStudent = null;
		// MessageBox.Show("Invalid Password");
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		int studentId;

		try {
			// convert student id to int
			studentId = Integer.parseInt(theStudentId);

			// get connection to database
			myConn = dataSource.getConnection();

			// create sql to get selected student
			String sql = "select * from employee where Emp_id=?";

			// create prepared statement
			myStmt = myConn.prepareStatement(sql);

			// set params
			myStmt.setInt(1, studentId);

			// execute statement
			myRs = myStmt.executeQuery();

			// retrieve data from result set row
			if (myRs.next()) {
				String firstName = myRs.getString("first_name");
				String lastName = myRs.getString("last_name");
				String email = myRs.getString("email");

				// use the studentId during construction
				// theStudent = new EmployeeClass(studentId, firstName, email);
			} else {
				throw new Exception("Could not find student id: " + studentId);
			}

			return theStudent;
		} finally {
			// clean up JDBC objects
			close(myConn, myStmt, myRs);
		}
	}

	public void updateStudent(EmployeeClass theStudent) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;

		try {
			// get db connection
			myConn = dataSource.getConnection();

			// create SQL update statement
			String sql = "update employee " + "set first_name=?, last_name=?, email=? " + "where id=?";

			// prepare statement
			myStmt = myConn.prepareStatement(sql);

			// set params
			myStmt.setString(1, theStudent.getFirstName());
			myStmt.setString(2, theStudent.getLastName());
			myStmt.setString(3, theStudent.getEmail());
			myStmt.setInt(4, theStudent.getId());

			// execute SQL statement
			myStmt.execute();
		} finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
	}

	public void deleteStudent(String theStudentId) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;

		try {
			// convert student id to int
			int studentId = Integer.parseInt(theStudentId);

			// get connection to database
			myConn = dataSource.getConnection();

			// create sql to delete student
			String sql = "delete from employee where Emp_id=?";

			// prepare statement
			myStmt = myConn.prepareStatement(sql);

			// set params
			myStmt.setInt(1, studentId);

			// execute sql statement
			myStmt.execute();
		} finally {
			// clean up JDBC code
			close(myConn, myStmt, null);
		}
	}

	@Override

	public void sendMail(String EmpName, String password, String receiverEmail) throws Exception {
		Properties properties = new Properties();
		String from = "Smart.IVR@cognizant.com";
		String host = "APACSMTP.CTS.COM";
		Session session;
		properties = System.getProperties();
		properties.setProperty("mail.smtp.host", host);
		session = Session.getDefaultInstance(properties);

		System.out.println("\nInside sendMail for user password method-");
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));

			System.out.println("Inside try block");

			message.addRecipient(Message.RecipientType.TO, new InternetAddress(receiverEmail));

			message.setSubject("Auto Mailer | Smart IVR Activity portal password");

			message.setText("Dear " + EmpName + ",\n\nYour password for Smart IVR Activity portal is " + password
					+ "\n\nThanks & Regards,\nSmart IVR");

			Transport.send(message);
			System.out.print("Email sent successfully...........");
			// logger.info("Email sent successfully...........");
		} catch (MessagingException mex) {
			mex.printStackTrace();
		}
	}

	@Override
	public void addActivity(String date, String time, String customer, String categorization, String description)
			throws Exception {
		Connection myConn = null;
		PreparedStatement myStmt = null;

		try {
			// get db connection
			myConn = dataSource.getConnection();
			System.out.println("String Date is " + date);

			String sql = "insert into activity_detail "
					+ "(activitydate,activitytime,customer,categorization,description) "
					+ "values (TO_DATE(?,'mm/dd/yyyy'),?,?,?,?)";

			myStmt = myConn.prepareStatement(sql);

			myStmt.setString(1, date);
			myStmt.setString(2, time);
			myStmt.setString(3, customer);
			myStmt.setString(4, categorization);
			myStmt.setString(5, description);
			// execute sql insert
			myStmt.execute();
		} finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
	}

	public ActivityBean getActivity(String fromDate, String toDate, String customer, String email) throws Exception {
		ActivityBean activity = null;
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		String activitydate, activitytime, customerName, categorization, description,emailid = null;

		try {

			myConn = dataSource.getConnection();

			String sql = "SELECT * FROM activity_detail WHERE activitydate BETWEEN TO_DATE(?,'mm/dd/yyyy') AND TO_DATE(?,'mm/dd/yyyy')AND customer=?";

			// create prepared statement
			myStmt = myConn.prepareStatement(sql);

			// set params
			myStmt.setString(1, fromDate);
			myStmt.setString(2, toDate);
			myStmt.setString(3, customer);
			// execute statement
			myRs = myStmt.executeQuery();

			while (myRs.next()) {
				if (myRs.next()) {
					activitydate = myRs.getString("activitydate");
					activitytime = myRs.getString("activitytime");
					customerName = myRs.getString("customer");
					categorization = myRs.getString("categorization");
					description = myRs.getString("description");
                    emailid=myRs.getString("email");
					System.out.println("startDate is: " + activitydate + " " + activitytime + " " + customerName + " "
							+ categorization + " " + description);
					// use the studentId during construction
					activity = new ActivityBean(activitydate, activitytime, customerName, description,emailid);
				} else {
					throw new Exception("Could not find activity record: " + activity);
				}
				return activity;
			}
		} finally {
			// clean up JDBC objects
			close(myConn, myStmt, myRs);
		}
		return activity;
	}

	public boolean emailValidation(String email) {
		boolean status = false;
		Connection myConn = null;
		PreparedStatement myStmt = null;
		try {

			System.out.println("Inside Email validation method");
			myConn = dataSource.getConnection();
			String sql = "select * from register_user where emailid=?";

			myStmt = myConn.prepareStatement(sql);

			myStmt.setString(1, email);

			System.out.println("Value of email :" + email);

			ResultSet rs = myStmt.executeQuery();
			status = rs.next();

		} catch (Exception e) {
		} finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
		System.out.println("Status is: " + status);
		return status;
	}

	public boolean empIdValidation(String employeeId) {
		boolean status = false;
		Connection myConn = null;
		PreparedStatement myStmt = null;
		try {

			System.out.println("Inside Emp id validation method");
			myConn = dataSource.getConnection();
			String sql = "select * from register_user where employeeid=?";

			myStmt = myConn.prepareStatement(sql);

			myStmt.setString(1, employeeId);

			System.out.println("Value of employeeId :" + employeeId);

			ResultSet rs = myStmt.executeQuery();
			status = rs.next();

		} catch (Exception e) {
		} finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
		System.out.println("Status is: " + status);
		return status;
	}

	public String getPassword(String emailId) throws Exception {
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		String password = null;
		try {
			// get connection to database
			myConn = dataSource.getConnection();

			// create sql to get selected student
			String sql = "select password from register_user where emailid=?";

			// create prepared statement
			myStmt = myConn.prepareStatement(sql);

			// set params
			myStmt.setString(1, emailId);

			// execute statement
			myRs = myStmt.executeQuery();

			// retrieve data from result set row
			if (myRs.next()) {
				password = myRs.getString("password");
			} else {
				throw new Exception("Could not find password for " + emailId + "email id");
			}
			return password;
		} finally {
			// clean up JDBC objects
			close(myConn, myStmt, myRs);
		}
	}

	public String getEmployeeName(String emailId) throws Exception {
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		String empName = null;
		try {
			// get connection to database
			myConn = dataSource.getConnection();

			// create sql to get selected student
			String sql = "select empfirstname from register_user where emailid=?";

			// create prepared statement
			myStmt = myConn.prepareStatement(sql);

			// set params
			myStmt.setString(1, emailId);

			// execute statement
			myRs = myStmt.executeQuery();

			// retrieve data from result set row
			if (myRs.next()) {
				empName = myRs.getString("empfirstname");
			} else {
				throw new Exception("Could not find password for " + emailId + "email id");
			}
			return empName;
		} finally {
			// clean up JDBC objects
			close(myConn, myStmt, myRs);
		}
	}

	@Override
	public List<EmployeeClass> getActivityDetails(String customer) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * static Writer writer = null; static String field = "\"TimeStamp\"";
	 * 
	 * public void listDownload() { Connection myConn = null; try { myConn =
	 * dataSource.getConnection(); String dateTimeString = dateValue(); CopyManager
	 * copyManager = new CopyManager((BaseConnection) myConn); File file = new
	 * File("C:\\Transfer_Status\\Log_all" + dateTimeString + ".csv");
	 * FileOutputStream fileOutputStream = new FileOutputStream(file); copyManager.
	 * copyOut("COPY (SELECT * FROM transfer_record) TO STDOUT DELIMITER ',' CSV HEADER"
	 * , fileOutputStream); JOptionPane.showMessageDialog(null,
	 * "Successfully Converted", "Success", JOptionPane.OK_OPTION); } catch
	 * (Exception e1) { try { e1.printStackTrace();
	 * Class.forName("org.postgresql.Driver"); Connection connection = null;
	 * connection =
	 * DriverManager.getConnection("jdbc:postgresql://localhost:5434/Kohls_Report",
	 * "postgres", "root"); CopyManager copyManager = new
	 * CopyManager((BaseConnection) connection); String dateTimeString =
	 * dateValue(); File file = new File("C:\\Transfer_Status"); if (!file.exists())
	 * { file.mkdir(); } File file2 = new File("C:\\Transfer_Status\\Log_all" +
	 * dateTimeString + ".csv"); FileOutputStream fileOutputStream = new
	 * FileOutputStream(file); if (!file2.exists()) { file2.createNewFile();
	 * fileOutputStream = new FileOutputStream(file2, false); copyManager.
	 * copyOut("COPY (SELECT * FROM transfer_record) TO STDOUT DELIMITER ',' CSV HEADER"
	 * , fileOutputStream); } } catch (SQLException e) { e.printStackTrace();
	 * JOptionPane.showMessageDialog(null, "sql exception occured", "Exception",
	 * JOptionPane.OK_OPTION); String dateTimeString = dateValue(); File file = new
	 * File("C:\\Transfer_Status\\Log_all" + dateTimeString + ".csv"); //
	 * FileOutputStream fileOutputStream = new FileOutputStream(file); writer = new
	 * BufferedWriter(new FileWriter(file));
	 * writer.write("Logs could not be written for " + dateTimeString);
	 * writer.close(); } catch (ClassNotFoundException e) { e.printStackTrace();
	 * JOptionPane.showMessageDialog(null, "class not found exception occured",
	 * "Exception", JOptionPane.OK_OPTION); String dateTimeString = dateValue();
	 * File file = new File("C:\\Transfer_Status\\Log_all" + dateTimeString +
	 * ".csv"); FileOutputStream fileOutputStream = new FileOutputStream(file);
	 * writer = new BufferedWriter(new OutputStreamWriter(new
	 * FileOutputStream(file), "utf-8"));
	 * writer.write("Logs could not be written for " + dateTimeString); } catch
	 * (IOException e) { e.printStackTrace(); JOptionPane.showMessageDialog(null,
	 * "IO exception occured", "Exception", JOptionPane.OK_OPTION);
	 * Class.forName("org.postgresql.Driver"); Connection connection = null;
	 * connection =
	 * DriverManager.getConnection("jdbc:postgresql://localhost:5434/Kohls_Report",
	 * "postgres", "root"); CopyManager copyManager = new
	 * CopyManager((BaseConnection) connection); String dateTimeString =
	 * dateValue(); File file2 = new File("C:\\Transfer_Status\\Log_all" +
	 * dateTimeString + ".csv"); FileOutputStream fileOutputStream = new
	 * FileOutputStream(file2); if (!file2.exists()) { file2.createNewFile();
	 * fileOutputStream = new FileOutputStream(file2, false); copyManager.
	 * copyOut("COPY (SELECT * FROM transfer_record) TO STDOUT DELIMITER ',' CSV HEADER"
	 * , fileOutputStream); } else { copyManager.
	 * copyOut("COPY (SELECT * FROM transfer_record) TO STDOUT DELIMITER ',' CSV HEADER"
	 * , fileOutputStream); } }
	 * 
	 * }
	 */
	public static String dateValue() {
		String dateString = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		dateString = dateFormat.format(cal.getTime());
		return dateString;
	}
	
	
	public String checkAccess(String empemailid) throws Exception {
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		String role = null;
		try {
			// get connection to database
			myConn = dataSource.getConnection();

			// create sql to get selected student
			String sql = "select role from employee_detail where empemailid=?";

			// create prepared statement
			myStmt = myConn.prepareStatement(sql);

			// set params
			myStmt.setString(1, empemailid);

			// execute statement
			myRs = myStmt.executeQuery();

			// retrieve data from result set row
			if (myRs.next()) {
				role = myRs.getString("role");
			} else {
				throw new Exception("Could not find role for " + role + "email id");
			}
			return role;
		} finally {
			// clean up JDBC objects
			close(myConn, myStmt, myRs);
		}
	}

	public List<ActivityBean> checkProjects(String fromDate, String toDate, String empemailid) {
		// TODO Auto-generated method stub
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		String activitydate, activitytime, customerName, description,emailid = null;
		ActivityBean activityObject = null;
		List<ActivityBean> studentBean = new ArrayList<ActivityBean>();

		try {
			myConn = dataSource.getConnection();

			String sql = "SELECT * FROM activity_detail WHERE activitydate BETWEEN TO_DATE(?,'mm/dd/yyyy') AND TO_DATE(?,'mm/dd/yyyy')AND empemailid=?";

			// create prepared statement
			myStmt = myConn.prepareStatement(sql);

			// set params
			myStmt.setString(1, fromDate);
			myStmt.setString(2, toDate);
			myStmt.setString(3, empemailid);
			// execute statement
			myRs = myStmt.executeQuery();

			while (myRs.next()) {
				activitydate = myRs.getString("activitydate");
				activitytime = myRs.getString("activitytime");
				customerName = myRs.getString("customer");
				description = myRs.getString("description");
                emailid=myRs.getString("empemailid");
				System.out.println(
						"View activity: " + activitydate + " " + activitytime + " " + customerName + " " + description  );
				// use the studentId during construction
				activityObject = new ActivityBean(activitydate, activitytime, customerName, description,emailid);
				studentBean.add(activityObject);
			}
		} catch (Exception e) {
			System.out.println("Exception in getActivityDetails method- " + e);
		} finally {
			// close JDBC objects
			close(myConn, myStmt, myRs);
		}
		return studentBean;
	}

	public List<ActivityBean> getActivityDetails(String fromDate, String toDate, String customer, String empemailid) {
		// TODO Auto-generated method stub
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		String activitydate, activitytime, customerName, description,emailid = null;
		ActivityBean activityObject = null;
		List<ActivityBean> studentBean = new ArrayList<ActivityBean>();

		try {
			myConn = dataSource.getConnection();

			String sql = "SELECT * FROM activity_detail WHERE activitydate BETWEEN TO_DATE(?,'mm/dd/yyyy') AND TO_DATE(?,'mm/dd/yyyy')AND customer=?";

			// create prepared statement
			myStmt = myConn.prepareStatement(sql);

			// set params
			myStmt.setString(1, fromDate);
			myStmt.setString(2, toDate);
			myStmt.setString(3, customer);
			// execute statement
			myRs = myStmt.executeQuery();

			while (myRs.next()) {
				activitydate = myRs.getString("activitydate");
				activitytime = myRs.getString("activitytime");
				customerName = myRs.getString("customer");
				description = myRs.getString("description");
                emailid=myRs.getString("empemailid");
				System.out.println(
						"View activity: " + activitydate + " " + activitytime + " " + customerName + " " + description + "" +empemailid  );
				// use the studentId during construction
				activityObject = new ActivityBean(activitydate, activitytime, customerName, description,emailid);
				studentBean.add(activityObject);
			}
		} catch (Exception e) {
			System.out.println("Exception in getActivityDetails method- " + e);
		} finally {
			// close JDBC objects
			close(myConn, myStmt, myRs);
		}
		return studentBean;
	}

	public void addUser(String empemailid, String role) throws SQLException {
		
		Connection myConn = null;
		PreparedStatement myStmt = null;

		try {
			// get db connection
			myConn = dataSource.getConnection();
			System.out.println("String email is " + empemailid);

			String sql = "insert into employee_detail "
					+ "(empemailid,role) "
					+ "values (?,?)";

			myStmt = myConn.prepareStatement(sql);

			myStmt.setString(1, empemailid);
			myStmt.setString(2, role);
			
			// execute sql insert
			myStmt.execute();
		} finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
		
		
	}

	public void addActivity(String date, String time, String customer, String categorization, String description,
			String email) throws SQLException {
		// TODO Auto-generated method stub
		Connection myConn = null;
		PreparedStatement myStmt = null;

		try {
			// get db connection
			myConn = dataSource.getConnection();
			System.out.println("String Date is " + date);

			String sql = "insert into activity_detail "
					+ "(activitydate,activitytime,customer,categorization,description,empemailid) "
					+ "values (TO_DATE(?,'mm/dd/yyyy'),?,?,?,?,?)";

			myStmt = myConn.prepareStatement(sql);

			myStmt.setString(1, date);
			myStmt.setString(2, time);
			myStmt.setString(3, customer);
			myStmt.setString(4, categorization);
			myStmt.setString(5, description);
			myStmt.setString(6, email);
			// execute sql insert
			myStmt.execute();
		} finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
	}

	
	
	
		
		
	}

	
