package com.cts.ivr.bean;

public class Employeeuserdetails {
	
	String empmailid;
	String role;
	public String getEmpmailid() {
		return empmailid;
	}
	public void setEmpmailid(String empmailid) {
		this.empmailid = empmailid;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Employeeuserdetails(String empmailid, String role) {
		super();
		this.empmailid = empmailid;
		this.role = role;
	}
	@Override
	public String toString() {
		return "Employeeuserdetails [empmailid=" + empmailid + ", role=" + role + "]";
	}
	
	
	
	

}
