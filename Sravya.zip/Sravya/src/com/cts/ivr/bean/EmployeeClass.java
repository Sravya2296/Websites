package com.cts.ivr.bean;

public class EmployeeClass {

	private int id;
	private String empId;
	private String firstName;
	private String lastName;
	private String email;
	private String activityDate;
	private String activityTime;
	private String customer;
	private String categorization;
	private String description;
	private String mobNumber;
	private String password;
	private String role;

	public EmployeeClass(String empId, String firstName, String lastName, String email, String mobNumber,
			String password) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.mobNumber = mobNumber;
		this.password = password;
	}

	public EmployeeClass(int id, String empId, String firstName, String lastName, String email, String activityDate,
			String activityTime, String customer, String categorization, String description, String mobNumber,
			String password, String role) {
		super();
		this.id = id;
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.activityDate = activityDate;
		this.activityTime = activityTime;
		this.customer = customer;
		this.categorization = categorization;
		this.description = description;
		this.mobNumber = mobNumber;
		this.password = password;
		this.role = role;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public EmployeeClass(String activityDate, String activityTime, String customer, String categorization,
			String description) {
		super();
		this.activityDate = activityDate;
		this.activityTime = activityTime;
		this.customer = customer;
		this.categorization = categorization;
		this.description = description;
	}

	public String getActivityDate() {
		return activityDate;
	}

	public void setActivityDate(String activityDate) {
		this.activityDate = activityDate;
	}

	public String getActivityTime() {
		return activityTime;
	}

	public void setActivityTime(String activityTime) {
		this.activityTime = activityTime;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getCategorization() {
		return categorization;
	}

	public void setCategorization(String categorization) {
		this.categorization = categorization;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public EmployeeClass(String firstName, String lastName, String email) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	}

	public EmployeeClass(String empId, String firstName) {
		this.empId = empId;
		this.firstName = firstName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public String getMobNumber() {
		return mobNumber;
	}

	public void setMobNumber(String mobNumber) {
		this.mobNumber = mobNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "EmployeeClass [id=" + id + ", empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", email=" + email + ", activityDate=" + activityDate + ", activityTime=" + activityTime
				+ ", customer=" + customer + ", categorization=" + categorization + ", description=" + description
				+ ", mobNumber=" + mobNumber + ", password=" + password + ", role=" + role + "]";
	}
	
}
